public class PastTime {

    public static int monthConversor (int age){
        return age * 12;
    }
    public static void main(String[] args) {
        int idadeAnos = 19;

        System.out.println(monthConversor(idadeAnos));
    }
}
