public class ITry {
    public static void main(String[] args){
        String me = "Matheus";

        System.out.println(me + " é um aluno dedicado!");
    }
}
