public class HasWallet {
    public static void main(String[] args) {    
        boolean temCarteira = false;
        temCarteira = true;
        
        System.out.println(temCarteira);
    }
}
