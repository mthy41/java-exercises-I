public class Char {
    public static void main(String[] args) {
        char letterA = 'a';
        System.out.println(letterA);
    }
}
