public class Fruits {
    public static void main(String[] args){
        String fruta1 = "uva";
        String fruta2 = "abacaxi";

        System.out.println("Eu gosto " + fruta1 + " e " + fruta2 + ".");
    }
}
