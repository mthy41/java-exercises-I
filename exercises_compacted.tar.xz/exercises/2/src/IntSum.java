public class IntSum {

    public static int sum(int num1, int num2){
        return num1 + num2;
    }
    public static void main(String[] args) {
        int num1 = 1;
        int num2 = 10;

        System.out.println(sum(num1, num2));
    }
}
