public class OlaPlusMundo {
    public static void main(String[] args){
        String frase = "Olá" + "Mundo";

        // A atividade não pedia para concatenar um espaço vazio entre as palavras.
        // Portanto, o resultado vai ser a impressão das duas palavras coladas.

        System.out.println(frase);
    }
}
