public class DoubleProd {

    public static double produtMethod(double num1, int num2){
        return num1 * num2;
    }
    public static void main(String[] args) {
        double num1 = 5.67;
        int num2 = 3;
        double produtResult = produtMethod(num1, num2);
        System.out.println(produtResult);
    }
}
