public class OlaMundo {
    public static void main(String[] args){
        System.out.println("Olá, Mundo!");
    }
}
