public class Boolean {
    public static void main(String[] args) {
        boolean boolVar = true;

        System.out.println(boolVar);
    }
}
